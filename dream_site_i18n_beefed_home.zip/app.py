
import os, json
from flask import Flask, render_template, url_for, request, redirect, make_response

app = Flask(__name__)

LANGS = ["en","ru"]

def load_tx():
    tx = {}
    for lang in LANGS:
        with open(os.path.join("i18n", f"{lang}.json"), "r", encoding="utf-8") as f:
            tx[lang] = json.load(f)
    return tx

TX = load_tx()

def get_lang():
    lang = request.cookies.get("lang","en")
    if lang not in LANGS:
        lang = "en"
    return lang

def t(key):
    lang = get_lang()
    def lookup(lang_key):
        val = TX.get(lang_key, {})
        for part in key.split("."):
            if isinstance(val, dict) and part in val:
                val = val[part]
            else:
                return None
        return val
    out = lookup(lang)
    if out is None:
        out = lookup("en") or key
    return out

NAV = [
    ("home", "nav.home", "/"),
    ("overview", "nav.overview", "/overview"),
    ("axioms", "nav.axioms", "/axioms"),
    ("math", "nav.math", "/math"),
    ("kernel", "nav.kernel", "/kernel"),
    ("topology", "nav.topology", "/topology"),
    ("spectrum", "nav.spectrum", "/spectrum"),
    ("predictions", "nav.predictions", "/predictions"),
    ("falsification", "nav.falsification", "/falsification"),
    ("faq", "nav.faq", "/faq"),
    ("about", "nav.about", "/about"),
]

@app.context_processor
def inject_globals():
    return dict(_=t, NAV=NAV, LANGS=LANGS, lang=get_lang())

@app.get("/setlang/<lang_code>")
def setlang(lang_code):
    resp = redirect(request.referrer or url_for("home"))
    if lang_code in LANGS:
        resp.set_cookie("lang", lang_code, max_age=60*60*24*365)
    return resp

@app.route("/")
def home():
    return render_template("home.html", title=t("meta.title"))

@app.route("/overview")
def overview():
    return render_template("overview.html", title=t("nav.overview"))

@app.route("/axioms")
def axioms():
    return render_template("axioms.html", title=t("nav.axioms"))

@app.route("/math")
def math():
    return render_template("math.html", title=t("nav.math"))

@app.route("/kernel")
def kernel():
    return render_template("kernel.html", title=t("nav.kernel"))

@app.route("/topology")
def topology():
    return render_template("topology.html", title=t("nav.topology"))

@app.route("/spectrum")
def spectrum():
    return render_template("spectrum.html", title=t("nav.spectrum"))

@app.route("/predictions")
def predictions():
    return render_template("predictions.html", title=t("nav.predictions"))

@app.route("/falsification")
def falsification():
    return render_template("falsification.html", title=t("nav.falsification"))

@app.route("/faq")
def faq():
    return render_template("faq.html", title=t("nav.faq"))

@app.route("/about")
def about():
    return render_template("about.html", title=t("nav.about"))

if __name__ == "__main__":
    app.run(debug=True, use_reloader=False)
